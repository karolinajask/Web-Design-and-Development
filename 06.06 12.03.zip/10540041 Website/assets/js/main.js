$(document).ready(function() {
	$('#narrow-menu-title').click(function() {
		$('.narrow-menu ul.nav-links').toggle(500);

	});	

	$(".more-btn").on('click',function(){
		$(this).parent().parent().find(".more-text").toggleClass("active");
	});
  		
	$("#wrapper").submit(function() {

		$("#l-inner").empty();
		var error_count = 0;
				
		var fname = $("#fname").val();
		if (fname == "") {
			$("input#fname").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>First name cannot be blank</p>");
		}

		var lname = $("#lname").val();
			if (lname == "") {
			$("input#lname").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Last name cannot be blank</p>");
		}

		var email = $("#email").val();
		if (email == "") {
			$("input#email").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Email address cannot be blank</p>");
		}

		var phone = $("#phone").val();
		if (phone == "") {
			$("input#phone").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Phone number cannot be blank</p>");
		}

		var start_date = $("#start_date").val();
		if(start_date == "") {
			$("#start_date").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Check-in date cannot be blank</p>");
		}
	
		var start_date = $("#start_date").val();
		var today = $(Date).val();
		if  (start_date < today) {
			$("#start_date").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Check-in date cannot be in the past</p>");
		}

		var end_date = $("#end_date").val();
		if(end_date == "") {
			$("#end_date").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Check-out date cannot be blank</p>");
		}

		var end_date = $("#end_date").val();
		var today = $(Date).val();
		if  (end_date < today) {
			$("#end_date").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Check-out date cannot be in the past</p>");
		}
	
		var end_date = $("#end_date").val();
		if (end_date < start_date) {
			$("#end_date").css("border-color", "#ff3333");
			$("#start_date").css("border-color", "#ff3333");
			error_count += 1;
			$("#l-inner").append("<p>Check-out must be after check-in date</p>")
		}	

		if (error_count > 0) {
			$("span#error-count").text(error_count).fadeIn(1200);
			$("p#error-list").css("color", "#ff3333").fadeIn(1200);
			$("#error-check").css("color", "#ff3333").fadeIn(1200);
			event.preventDefault();
			
		}
		
	});

});

